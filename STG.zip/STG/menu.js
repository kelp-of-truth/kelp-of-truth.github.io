let actv_txt=0;
const game_start_img=new Image();
const quit_img=new Image();
function startMenu(){
    const ctx=canvas.getContext("2d");
    ctx.fillStyle="black";
    ctx.fillRect(0,0,540,720);
    if(prskey[38]&&actv_txt===1){actv_txt=0;prskey[38]=false}
    if(prskey[40]&&actv_txt===0){actv_txt=1;prskey[40]=false}
    if(prskey[90]){
        if(actv_txt===0){
            loopID="selectDiff";
        }else
        if(actv_txt===1){window.close()}
        prskey[90]=false;
    }
    if(prskey[88]||prskey[27]){
        if(actv_txt===0){actv_txt=1}else
        if(actv_txt===1){window.close()}
        prskey[88]=false;
        prskey[27]=false;
    }
    if(actv_txt===0){
        game_start_img.src="./text/game_start_active.png";
        quit_img.src="./text/quit.png";
        ctx.drawImage(game_start_img,198,600,144,45);
        ctx.drawImage(quit_img,206,650);
    }
    if(actv_txt===1){
        game_start_img.src="./text/game_start.png";
        quit_img.src="./text/quit_active.png";
        ctx.drawImage(game_start_img,206,600);
        ctx.drawImage(quit_img,198,650,144,45);
    }
}
const diff_easy_img=new Image();
diff_easy_img.src="./text/diff_easy.png";
const diff_hard_img=new Image();
diff_hard_img.src="./text/diff_hard.png";
let actv_diff=0;
function selectDiff(){
    const ctx=canvas.getContext("2d");
    ctx.fillStyle="black";
    ctx.fillRect(0,0,540,720);
    if(prskey[38]&&actv_diff===1){actv_diff=0;prskey[38]=false}
    if(prskey[40]&&actv_diff===0){actv_diff=1;prskey[40]=false}
    if(prskey[27]||prskey[88]){loopID="startMenu";prskey[88]=false;prskey[27]=false}
    if(prskey[90]){
        loopID="game_easy"
    }
    if(actv_diff===0){
        ctx.drawImage(diff_easy_img,80,296,340,128);
        ctx.drawImage(diff_hard_img,140,480,320,120);
        ctx.fillStyle="rgba(0, 0, 0, 0.5)";
        ctx.fillRect(140,480,310,120);
    }
    if(actv_diff===1){
        ctx.drawImage(diff_easy_img,140,120,320,120);
        ctx.drawImage(diff_hard_img,80,296,340,128);
        ctx.fillStyle="rgba(0, 0, 0, 0.5)";
        ctx.fillRect(140,120,310,120);
    }
}