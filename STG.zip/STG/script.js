let connectedGamepadIndex;
let loopID="game_easy";
let prskey=[];
prskey[16]=false;
document.addEventListener("keydown",(e)=>{prskey[e.keyCode]=true})
document.addEventListener("keyup",(e)=>{prskey[e.keyCode]=false})
addEventListener("gamepadconnected", (e) => {
    console.log("Connected");
    connectedGamepadIndex = e.gamepad.index;
    // loopID = requestAnimationFrame(loop);
});
// loopID = requestAnimationFrame(loop);

addEventListener("gamepaddisconnected", (e) => {
    console.log("Disconnected");
    connectedGamepadIndex = null;
    // cancelAnimationFrame(loopID);
});
const BUTTON_A_INDEX     = 0;
const BUTTON_B_INDEX     = 1;
const BUTTON_X_INDEX     = 2;
const BUTTON_Y_INDEX     = 3;
const BUTTON_LB_INDEX    = 4;
const BUTTON_RB_INDEX    = 5;
const BUTTON_LT_INDEX    = 6;
const BUTTON_RT_INDEX    = 7;
const BUTTON_BACK_INDEX  = 8;
const BUTTON_START_INDEX = 9;
const BUTTON_L3_INDEX    = 10;
const BUTTON_R3_INDEX    = 11;
const BUTTON_UP_INDEX    = 12;
const BUTTON_DOWN_INDEX  = 13;
const BUTTON_LEFT_INDEX  = 14;
const BUTTON_RIGHT_INDEX = 15;
const BUTTON_HOME_INDEX  = 16;
// ===============================
const AXIS_L_HORIZONTAL_INDEX = 0;
const AXIS_L_VERTICAL_INDEX   = 1;
const AXIS_R_HORIZONTAL_INDEX = 2;
const AXIS_R_VERTICAL_INDEX   = 3;


let scene=0;


let sin=[];
let cos=[];

let bullet=[];
for(let i=0;i<1081;i++){
    sin[i]=Math.sin(toRad(i));
    cos[i]=Math.cos(toRad(i));
}
let interval=[];


const ziki=new Image(48,48);
const hitbox=new Image();
const bltImg=new Image();
ziki.src="./earth.png";
hitbox.src="./hitbox.png";
const canvas=document.querySelector("canvas");
function game_easy(){
    const ctx=canvas.getContext("2d");
    ctx.clearRect(-200,-200,740,920);
    // GamePad
    controls();
    ctx.fillStyle="black";
    ctx.fillRect(0,0,540,720);
    ctx.drawImage(ziki,omae.x/1000-24,omae.y/1000-24,48,48);
    const img=new Image();
    if(scene===30){
        bullet[0]=new Bullet(270,50,0,5);
    }
    if(scene>30&&scene<280){
        img.src="./bullet/ball_white.png";
        ctx.drawImage(img,bullet[0].x/1000,bullet[0].y/1000);
        bullet[0].move();
    }
    if(scene===60){
        bullet[1]=[];
        interval[0]=setInterval(() => {
            var deg=Math.floor(180*Math.atan2(bullet[0].y-omae.y,omae.x-bullet[0].x)/Math.PI);
            bullet[1][bullet[1].length]=new Bullet(deg,bullet[0].x/1000,bullet[0].y/1000,12);
        }, 500);
    }
    if(scene>60&&scene<680){
        for(let i=0;i<bullet[1].length;i++){
            var idx=bullet[1][i];
            img.src="./bullet/star-red.png";
            ctx.drawImage(img,idx.x/1000,idx.y/1000);
            idx.move();
            idx.age++;
            if(idx.age<10){continue}
            idx.v=5000;
        }
    }
    if(scene===180){
        clearInterval(interval[0]);
    }
    if(prskey[16]){ctx.drawImage(hitbox,omae.x/1000-8,omae.y/1000-8)}
    scene++;
}
setInterval(() => {eval(`requestAnimationFrame(${loopID})`)}, 33);

setInterval(() => {
    // for(let i=0;i<bullet[1].length;i++){
    //     var idx=bullet[1][i];
    //     if(idx.y>740000||idx.x>560000||idx.x<-200000||idx.y<200000){
    //         bullet[1]="";
    //     }
    // }
    // if(bullet[1]===undefined){
    //     bullet[0]=undefined;
    // }
}, 300);
let omae={
    x:282*1000,
    y:600*1000
}

function controls(){
    var mx=0;
    var my=0;
    // if(navigator.getGamepads()[0]!==null){
    //     let gamepads = navigator.getGamepads();
    //     let gp = gamepads[connectedGamepadIndex];
    //     let leftAxisHorizontal = Math.trunc(gp.axes[AXIS_L_HORIZONTAL_INDEX]*10)/10;
    //     let leftAxisVertical = Math.trunc(gp.axes[AXIS_L_VERTICAL_INDEX]*10)/10;
    // }
    if(prskey.indexOf(true)===-1){return true}
    if(prskey[37]&&prskey[38]){mx=-2828;my=-2828}else
    if(prskey[38]&&prskey[39]){mx=2828;my=-2828}else
    if(prskey[39]&&prskey[40]){mx=2828;my=2828}else
    if(prskey[40]&&prskey[37]){mx=-2828;my=2828}else
    if(prskey[37]){mx=-4000}else
    if(prskey[38]){my=-4000}else
    if(prskey[39]){mx=4000}else
    if(prskey[40]){my=4000}
        if(omae.x+mx<8000){omae.x=8000}else
        if(omae.x+mx>532000){omae.x=532000}else{omae.x+=mx*(2-(prskey[16]))}
        if(omae.y+my<8000){omae.y=8000}else
        if(omae.y+my>712000){omae.y=712000}else{omae.y+=my*(2-(prskey[16]))}


}

class Bullet{
    constructor(angle,x,y,v,vx,vy,age){
        this.angle=angle;
        this.x=x*1000;
        this.y=y*1000;
        this.v=v*1000;
        this.vx=cos[this.angle+360];
        this.vy=sin[this.angle+360];
        this.age=0;
    }
    move(){
        this.x+=this.vx*this.v;
        this.y-=this.vy*this.v;
    }
}
function toRad(n){
    return n/180*Math.PI;
}