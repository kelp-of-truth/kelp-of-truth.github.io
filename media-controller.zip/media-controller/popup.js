const pauseply=document.querySelector("#pause-play");
const previous=document.querySelector("#previous");
const next=document.querySelector("#next");

window.addEventListener("load",()=>{
    chrome.tabs.query({audible:true})
    .then((tabs)=>{
        let tabid=tabs[0].id;
        // if(localStorage.getItem("tabid")!==null){
        //     tabid=localStorage.getItem("tabid");
        // }else{
        //     tabid=tabs[0].id;
        // }
        document.querySelector("main").hidden=false;
        chrome.tabs.sendMessage(tabid,{type:"load"},(res)=>{
            const mediasesison=res;
            document.querySelector("#artwork").src=`${mediasesison.artwork[mediasesison.artwork.length-1].src}`;
            document.querySelector("#wallpaper").src=`${mediasesison.artwork[mediasesison.artwork.length-1].src}`;
            document.querySelector("#title").innerHTML=`${mediasesison.title}`;
            document.querySelector("#artist").innerHTML=`${mediasesison.album}&nbsp;－&nbsp;${mediasesison.artist}`;

            pauseply.addEventListener("click",()=>{
                if(pauseply.ariaLabel==="play"){
                    pauseply.src="./img/pause.png";
                    pauseply.ariaLabel="pause";
                    chrome.scripting.executeScript({
                        target:{tabId:tabid},
                        func:mediaplay
                    })
                }else if(pauseply.ariaLabel==="pause"){
                    pauseply.src="./img/play.png";
                    pauseply.ariaLabel="play";
                    chrome.scripting.executeScript({
                        target:{tabId:tabid},
                        func:mediapause
                    })
                }
            })
            previous.addEventListener("click",()=>{
                chrome.scripting.executeScript({
                    target:{tabId:tabid},
                    func:mediaprevious
                })
            })
            next.addEventListener("click",()=>{
                chrome.scripting.executeScript({
                    target:{tabId:tabid},
                    func:medianext
                })
            })
            if(artist.scrollWidth>210){
                setInterval(() => {
                    if(Number(artist.style.left.replace(/px/g,""))<=210-artist.scrollWidth){
                        pausetime++;
                        if(pausetime===50){
                            artist.style.left="0px";
                        }
                    }else{
                        pausetime=0;
                        artist.style.left=`${Number(artist.style.left.replace(/px/g,""))-0.5}px`;
                    }
                }, 20);
            }
        })
    })
    .catch((err)=>{
        document.querySelector("main").hidden=true;
    })
})
function mediaplay(){
    document.querySelector("audio").play();
}
function mediapause(){
    document.querySelector("audio").pause();
}
function mediaprevious(){
    document.querySelector("audio").currentTime=0;
}
function medianext(){
    document.querySelector("audio").currentTime=document.querySelector("audio").duration;
}
const artist=document.querySelector("#artist");
const title=document.querySelector("#title");
let pausetime=0;
