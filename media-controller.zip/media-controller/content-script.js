chrome.runtime.onMessage.addListener((req,sender,sendResponse) => {
    const ms=navigator.mediaSession.metadata;
    const res={
        pagetitle:document.title,
        title:ms.title,
        artist:ms.artist,
        album:ms.album,
        artwork:ms.artwork
    }
    sendResponse(res);
});